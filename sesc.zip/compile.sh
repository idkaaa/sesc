#!/bin/bash
rsync -Lvurc --existing  /media/sf_sesc/build/SMP_BOOKSIM/ /media/sf_sesc/src/
scons build/SMP_BOOKSIM/sesc.opt
#make -b
rsync -Lavr --existing /media/sf_sesc/src/ /media/sf_sesc/build/SMP_BOOKSIM/
