#!/bin/bash
fileExtension=HyG.debug
confFile=~/sesc/confs/cmp4-noc.HyA.conf
sescOutputFile="sesc_raytrace.mipseb.$fileExtension"
reportFile="sesc_raytrace.mipseb.$fileExtension.report.txt"
rm -f "$sescOutputFile"
rm -f "$reportFile"
~/sesc/sesc.debug -f HyG.debug -c ~/sesc/confs/cmp4-noc.HyA.conf -ort.out -ert.err raytrace.mipseb -p1 -m128 -a2 Input/reduced.env
~/sesc/scripts/report.pl "$sescOutputFile" > "$reportFile"