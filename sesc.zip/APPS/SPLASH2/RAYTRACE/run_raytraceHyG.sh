#!/bin/bash
fileExtension=HyG
confFile=~/sesc/confs/cmp4-noc.HyA.conf
sescOutputFile="sesc_raytrace.mipseb.$fileExtension"
reportFile="sesc_raytrace.mipseb.$fileExtension.report.txt"
rm -f "$sescOutputFile"
rm -f "$reportFile"
~/sesc/sesc.opt -f $fileExtension -c \
$confFile \
-ort.out -ert.err raytrace.mipseb -p1 -m16 -a2 \
#Input/reduced.env
~/sesc/scripts/report.pl "$sescOutputFile" > "$reportFile"