#!/bin/bash
fileExtension=NTA
confFile=~/sesc/confs/cmp4-noc.$fileExtension.conf
sescOutputFile="sesc_raytrace.mipseb.$fileExtension"
reportFile="sesc_raytrace.mipseb.$fileExtension.report.txt"
rm -f "$sescOutputFile"
rm -f "$reportFile"
~/sesc/sesc.opt -f $fileExtension -c \
$confFile \
-ort.out -ert.err raytrace.mipseb -p1 -m128 -a2 \
Input/reduced.env
~/sesc/scripts/report.pl "$sescOutputFile" > "$reportFile"