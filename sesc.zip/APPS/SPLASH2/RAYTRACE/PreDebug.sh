#!/bin/bash

rm ~/sesc/apps/Splash2/raytrace/sesc_raytrace.mipseb.HyG.debug
