#!/bin/bash
fileExtension=n64
sescOutputFile="sesc_lu.mipseb.$fileExtension"
reportFile="sesc_lu.mipseb.$fileExtension.report.txt"
rm -f "$sescOutputFile"
rm -f "$reportFile"
~/sesc/sesc.opt -f $fileExtension -c ~/sesc/confs/cmp4-noc.conf \
-olu.out -elu.err lu.mipseb -$fileExtension -p1
~/sesc/scripts/report.pl "$sescOutputFile" > "$reportFile"
